﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace PseudoRandom
{
    public class ReverseComparerP : IComparer
    {
        // Call CaseInsensitiveComparer.Compare with the parameters reversed.

        public int Compare(Object x, Object y)
        {
            return (new CaseInsensitiveComparer()).Compare(x, y);
        }
    }
    public class ReverseComparer : IComparer
    {
        // Call CaseInsensitiveComparer.Compare with the parameters reversed.

        public int Compare(Object x, Object y)
        {
            return (new CaseInsensitiveComparer()).Compare((double)(((double[])x)[1]), (double)(((double[])y)[1]));
        }
    }
    public class ReverseComparer0 : IComparer
    {
        // Call CaseInsensitiveComparer.Compare with the parameters reversed.

        public int Compare(Object x, Object y)
        {
            return (new CaseInsensitiveComparer()).Compare((double)(((double[])x)[0]), (double)(((double[])y)[0]));
        }
    }
    public struct resul
    {
        public double xmin;
        public double Dn;
        public bool ris;
    }
    public class Product : IEquatable<Product>
    {
        public string Name { get; set; }
        public int Code { get; set; }

        public bool Equals(Product other)
        {

            //Check whether the compared object is null. 
            if (Object.ReferenceEquals(other, null)) return false;

            //Check whether the compared object references the same data. 
            if (Object.ReferenceEquals(this, other)) return true;

            //Check whether the products' properties are equal. 
            return Code.Equals(other.Code) && Name.Equals(other.Name);
        }

        // If Equals() returns true for a pair of objects  
        // then GetHashCode() must return the same value for these objects. 

        public override int GetHashCode()
        {

            //Get hash code for the Name field if it is not null. 
            int hashProductName = Name == null ? 0 : Name.GetHashCode();

            //Get hash code for the Code field. 
            int hashProductCode = Code.GetHashCode();

            //Calculate the hash code for the product. 
            return hashProductName ^ hashProductCode;
        }
    }
    public class MersenneTwister
    {

        #region "Private Parameter"
        /* Period parameters */
        private const Int16 N = 624;
        private const Int16 M = 397;
        private const UInt32 MATRIX_A = (UInt32)0x9908b0df;   /* constant vector a */
        private const UInt32 UPPER_MASK = (UInt32)0x80000000; /* most significant w-r bits */
        private const UInt32 LOWER_MASK = (UInt32)0x7fffffff; /* least significant r bits */
        private UInt32[] mt; /* the array for the state vector  */
        private UInt16 mti; /* mti==N+1 means mt[N] is not initialized */
        private UInt32[] mag01;
        #endregion

        #region "Constructor"

        public MersenneTwister(UInt32 s)
        {
            MT();
            init_genrand(s);
        }

        // coded by Mitil. 2006/01/04
        public MersenneTwister()
        {
            MT();

            // auto generate seed for .NET
            UInt32[] seed_key = new UInt32[6];
            Byte[] rnseed = new Byte[8];

            seed_key[0] = (UInt32)System.DateTime.Now.Millisecond;
            seed_key[1] = (UInt32)System.DateTime.Now.Second;
            seed_key[2] = (UInt32)System.DateTime.Now.DayOfYear;
            seed_key[3] = (UInt32)System.DateTime.Now.Year;
            ;
            System.Security.Cryptography.RandomNumberGenerator rn
                = new System.Security.Cryptography.RNGCryptoServiceProvider();
            rn.GetNonZeroBytes(rnseed);

            seed_key[4] = ((UInt32)rnseed[0] << 24) | ((UInt32)rnseed[1] << 16)
                | ((UInt32)rnseed[2] << 8) | ((UInt32)rnseed[3]);
            seed_key[5] = ((UInt32)rnseed[4] << 24) | ((UInt32)rnseed[5] << 16)
                | ((UInt32)rnseed[6] << 8) | ((UInt32)rnseed[7]);

            init_by_array(seed_key);

            rn = null;
            seed_key = null;
            rnseed = null;
        }

        public MersenneTwister(UInt32[] init_key)
        {
            MT();

            init_by_array(init_key);
        }

        private void MT()
        {
            mt = new UInt32[N];

            mag01 = new UInt32[] { 0, MATRIX_A };
            /* mag01[x] = x * MATRIX_A  for x=0,1 */

            mti = N + 1;
        }

        #endregion

        #region "Destructor"
        ~MersenneTwister()
        {
            mt = null;
            mag01 = null;
        }
        #endregion

        #region "seed init"
        /* initializes mt[N] with a seed */
        private void init_genrand(UInt32 s)
        {
            mt[0] = s;

            for (mti = 1; mti < N; mti++)
            {
                mt[mti] =
                    ((UInt32)1812433253 * (mt[mti - 1] ^ (mt[mti - 1] >> 30)) + mti);
                /* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
                /* In the previous versions, MSBs of the seed affect   */
                /* only MSBs of the array mt[].                        */
                /* 2002/01/09 modified by Makoto Matsumoto             */
            }
        }

        /* initialize by an array with array-length */
        /* init_key is the array for initializing keys */
        /* key_length is its length */
        /* slight change for C++, 2004/2/26 */
        private void init_by_array(UInt32[] init_key)
        {
            UInt32 i, j;
            Int32 k;
            Int32 key_length = init_key.Length;

            init_genrand(19650218);
            i = 1; j = 0;
            k = (N > key_length ? N : key_length);

            for (; k > 0; k--)
            {
                mt[i] = (mt[i] ^ ((mt[i - 1] ^ (mt[i - 1] >> 30)) * (UInt32)1664525))
                    + init_key[j] + (UInt32)j; /* non linear */
                i++; j++;
                if (i >= N) { mt[0] = mt[N - 1]; i = 1; }
                if (j >= key_length) j = 0;
            }
            for (k = N - 1; k > 0; k--)
            {
                mt[i] = (mt[i] ^ ((mt[i - 1] ^ (mt[i - 1] >> 30)) * (UInt32)1566083941))
                    - (UInt32)i; /* non linear */
                i++;
                if (i >= N) { mt[0] = mt[N - 1]; i = 1; }
            }

            mt[0] = 0x80000000; /* MSB is 1; assuring non-zero initial array */
        }
        #endregion

        #region "Get Unsigned Int 32bit number"
        /* generates a random number on [0,0xffffffff]-Interval */
        public UInt32 genrand_Int32()
        {
            UInt32 y;

            if (mti >= N)
            { /* generate N words at one time */
                Int16 kk;

                if (mti == N + 1)   /* if init_genrand() has not been called, */
                    init_genrand(5489); /* a default initial seed is used */

                for (kk = 0; kk < N - M; kk++)
                {
                    y = ((mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK)) >> 1;
                    mt[kk] = mt[kk + M] ^ mag01[mt[kk + 1] & 1] ^ y;
                }
                for (; kk < N - 1; kk++)
                {
                    y = ((mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK)) >> 1;
                    mt[kk] = mt[kk + (M - N)] ^ mag01[mt[kk + 1] & 1] ^ y;
                }
                y = ((mt[N - 1] & UPPER_MASK) | (mt[0] & LOWER_MASK)) >> 1;
                mt[N - 1] = mt[M - 1] ^ mag01[mt[0] & 1] ^ y;

                mti = 0;
            }

            y = mt[mti++];

            /* Tempering */
            y ^= (y >> 11);
            y ^= (y << 7) & 0x9d2c5680;
            y ^= (y << 15) & 0xefc60000;
            y ^= (y >> 18);

            return y;
        }
        #endregion

        #region "Get Int31 number"
        /* generates a random number on [0,0x7fffffff]-Interval */
        public UInt32 genrand_Int31()
        {
            return (genrand_Int32() >> 1);
        }
        #endregion

        #region "Get type'double' number"
        /* generates a random number on [0,1]-real-Interval */
        public double genrand_real1()
        {
            return genrand_Int32() * ((double)1.0 / 4294967295.0);
            /* divided by 2^32-1 */
        }

        /* generates a random number on [0,1)-real-Interval */
        public double genrand_real2()
        {
            return genrand_Int32() * ((double)1.0 / 4294967296.0);
            /* divided by 2^32 */
        }

        /* generates a random number on (0,1)-real-Interval */
        public double genrand_real3()
        {
            return (((double)genrand_Int32()) + 0.5) * ((double)1.0 / 4294967296.0);
            /* divided by 2^32 */
        }

        /* generates a random number on [0,1) with 53-bit resolution*/
        public double genrand_res53()
        {
            UInt32 a = genrand_Int32() >> 5, b = genrand_Int32() >> 6;
            return ((double)a * 67108864.0 + b) * ((double)1.0 / 9007199254740992.0);
        }
        /* These real versions are due to Isaku Wada, 2002/01/09 added */
        #endregion

    }
}

